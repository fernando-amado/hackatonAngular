import { SizeDirective } from './size.directive';

describe('SizeDirective', () => {
  it('should create an instance', () => {
    const directive = new SizeDirective();
    expect(directive).toBeTruthy();
  });
});
